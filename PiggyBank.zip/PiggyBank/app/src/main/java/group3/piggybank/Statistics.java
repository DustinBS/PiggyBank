package group3.piggybank;

import java.util.List;

public class Statistics {

    private double total;
    private double average;
    private List<Category> expenseTypes;
    private double profit;
    private double loss;

    public Statistics(double total, double average,
                      List<Category> expenseTypes, double profit, double loss) {
        this.total = total;
        this.average = average;
        this.expenseTypes = expenseTypes;
        this.profit = profit;
        this.loss = loss;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public double getAverage() {
        return average;
    }

    public void setAverage(double average) {
        this.average = average;
    }

    public List<Category> getExpenseTypes() {
        return expenseTypes;
    }

    public void setExpenseTypes(List<Category> expenseTypes) {
        this.expenseTypes = expenseTypes;
    }

    public double getProfit() {
        return profit;
    }

    public void setProfit(double profit) {
        this.profit = profit;
    }

    public double getLoss() {
        return loss;
    }

    public void setLoss(double loss) {
        this.loss = loss;
    }

    private double calculateTotal() {

        return 0.0;
    }
}

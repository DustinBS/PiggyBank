package group3.piggybank;

import java.util.Objects;

public class Money {

    private int dollar;
    private int cents;
    private int day;
    private int month;
    private int year;
    private boolean isIncome;
    private Category expenseType;

    public Money() {
    }

    public Money(int dollar, int cents, int day, int month,
                 int year, boolean isIncome, Category expenseType) {
        this.dollar = dollar;
        this.cents = cents;
        this.day = day;
        this.month = month;
        this.year = year;
        this.isIncome = isIncome;
        this.expenseType = expenseType;
    }

    public int getDollar() {
        return dollar;
    }

    public void setDollar(int dollar) {
        this.dollar = dollar;
    }

    public int getCents() {
        return cents;
    }

    public void setCents(int cents) {
        this.cents = cents;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public boolean isIncome() {
        return isIncome;
    }

    public void setIncome(boolean income) {
        isIncome = income;
    }

    public Category getExpenseType() {
        return expenseType;
    }

    public void setExpenseType(Category expenseType) {
        this.expenseType = expenseType;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Money money = (Money) o;
        return dollar == money.dollar &&
                cents == money.cents &&
                isIncome == money.isIncome;
    }

    @Override
    public int hashCode() {
        return Objects.hash(dollar, cents, isIncome);
    }

}
